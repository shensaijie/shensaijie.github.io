console.log(`     
This blog is using hexo-theme-kaze based on MIT license\nSee theme at https://github.com/theme-kaze/hexo-theme-kaze
`)
