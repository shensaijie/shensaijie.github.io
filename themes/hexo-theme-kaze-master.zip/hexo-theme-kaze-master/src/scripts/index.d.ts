interface Window {
  setDarkmode: Function
  reverseDarkModeSetting: Function
  mask: HTMLElement
  localSearch: Function
}
