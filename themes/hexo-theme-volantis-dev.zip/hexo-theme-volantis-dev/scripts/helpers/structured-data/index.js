/*globals hexo */
hexo.extend.helper.register("structured_data", require('./lib/'));
